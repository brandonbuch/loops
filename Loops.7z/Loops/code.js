
// While loop - while some condition happens, keep going. If statement. 
function whileCount() {
    // defining variables
    var currTime = 10;
    var i = 1;
    while (i < 12) {


        if (i == 11) {      
            setTimeout(function () {
                // this is the code for displaying the countdowntimer id, from the HTML file
                document.getElementById("countdownTimer").innerHTML = "Blastoff!!!";
            }, 1000 * i);
        } else if (i > 6) {
            setTimeout(function () {
                // innerHTML refreshes the HTML page instead of creating a new one
                document.getElementById("countdownTimer").innerHTML =
                // this displays when the timer is halfway done
                    "Warning Less than half way to launch, time left = " + currTime;
                currTime = currTime - 1;
            }, 1000 * i);
        } else {
            setTimeout(function () {
                // this displays the time left after the timer has reached the halfway point
                document.getElementById("countdownTimer").innerHTML = "the time left is " + currTime;
                currTime = currTime - 1;
            }, 1000 * i);
        }
        i = i + 1;
    }
}